---
name: docker
description: Run Docker commands within a container environment, including starting the Docker daemon and managing containers. Use when building, running, or managing Docker containers and images.
triggers:
- docker
- container
---

# Docker Usage Guide

## Starting Docker in Container Environments

Please check if docker is already installed. If so, to start Docker in a container environment:

```bash
# Start Docker daemon in the background
sudo dockerd > /tmp/docker.log 2>&1 &

# Wait for Docker to initialize
sleep 5
```

On Windows, start Docker Desktop or the Docker service instead of running `sudo dockerd`; then run Docker commands from PowerShell without `sudo`.

## Verifying Docker Installation

To verify Docker is working correctly, run the hello-world container:

```bash
sudo docker run hello-world
```

PowerShell equivalent after Docker Desktop is running: `docker run hello-world`.
