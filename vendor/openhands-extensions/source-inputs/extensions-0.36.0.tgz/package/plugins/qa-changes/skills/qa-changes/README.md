# qa-changes

Skill that provides a structured QA methodology for validating pull request changes. The agent actually runs the software — setting up the environment and exercising changed behavior as a real user would — rather than running the test suite (CI's job) or analyzing code (code review's job).

See the [qa-changes plugin](../../plugins/qa-changes/) for the GitHub Actions integration that automates this on every PR.

## Usage

Trigger the skill with `/qa-changes` in a conversation, or use it via the `qa-changes` plugin in a GitHub Actions workflow.

## Methodology

The skill guides the agent through four phases:

1. **Understand** — Classify changes and identify entry points
2. **Setup** — Install dependencies, build, check CI status
3. **Exercise** — Run the actual code as a user would (browser, CLI, API requests).
   For frontend changes, capture screenshots of each affected state and a GIF of
   the key interaction (before/after where behavior changes)
4. **Report** — Post a structured QA report with evidence and a verdict
